﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;
using System.Linq;

public class GameController : MonoBehaviour
{
    private DataController dataController;
    DatabaseController databaseController = new DatabaseController();
    private string[] questions;
    private int[] answers;
    private int questionIndex;
    private object totalScore;
    public Text question;
    public Text btn1;
    public Text btn2;
    public Text btn3;
    public Text score;
    public Text correctAnswer;
    public GameObject panelCorrect;
    public GameObject panelIncorrect;
    public GameObject panelLevelComplete;
    public GameObject engine;
    public GameObject engineOne;
    public GameObject engineTwo;
    public GameObject engineThree;
    public GameObject engineFour;
    public GameObject engineFive;
    public GameObject engineSix;
    public GameObject engineSeven;
    public GameObject engineEight;
    public GameObject engineNine;
    public GameObject caboose;
    private List<int> answerOptions;
    private System.Random rng = new System.Random();
    private string[] bonusQuestions;
    private int[][] bonusOptions;
    private int[] bonusAnswers;
    private int bonusIndex;
    private int correctQuestionsCount;
    private Boolean isBonusQuestion;
    // Start is called before the first frame update
    void Start()
    {
        dataController = FindObjectOfType<DataController>();
        dataController.generateData();
        dataController.generateBonus();
        questions = dataController.getQuestions();
        answers = dataController.getAnswers();
        bonusQuestions = dataController.getBonusQuestions();
        bonusOptions = dataController.getBonusOptions();
        bonusAnswers = dataController.getBonusAnswers();
        totalScore = databaseController.getTotalScore(PlayerPrefs.GetString("PlayerName"));
        score.text = "Score: " + totalScore;
        questionIndex = 0;
        bonusIndex = 0;
        correctQuestionsCount = 0;
        isBonusQuestion = false;
        checkPoints();
        showQuestions();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void showQuestions() {
        //make sure popups are inactive
        answerOptions = new List<int>();
        question.text = questions[questionIndex];
        answerOptions = getAnswerOptionList(answers[questionIndex]);
        Shuffle(answerOptions);
        btn1.text = "" + answerOptions[0];
        btn2.text = "" + answerOptions[1];
        btn3.text = "" + answerOptions[2];
    }

    public void Shuffle(List<int> list)
    {
        int n = list.Count;
        while (n > 1)
        {
            n--;
            int k = rng.Next(n + 1);
            int value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }

    public void buttonClicked(Text btnText) {
        //get answer from bonusAnswers if bonus question
        //otherwise not
        string answerString;
        if (this.isBonusQuestion)
        {
            answerString = bonusAnswers[bonusIndex].ToString();
        }
        else
        {
            answerString = answers[questionIndex].ToString();

        }
        if (btnText.text.Equals(answerString))
        {
            //toggle correct popup
            //add score
            //increase check question count
            correctQuestionsCount++;
            if (!this.isBonusQuestion)
            {
                totalScore = databaseController.updateScore(10, PlayerPrefs.GetString("PlayerName"));
            }
            score.text = "Score " + totalScore;
            this.checkPoints();
            panelCorrect.gameObject.SetActive(true);
            if (questionIndex < questions.Length-1)
            {
                //check question count
                //if it's true do bonus question
                if (this.checkCorrectQuestionCount())
                {
                    //toggle some kind of bonus questions message
                    isBonusQuestion = true;
                    correctQuestionsCount = 0;
                    showBonusQuestions();
                }
                else
                {
                    //if not procede as normal
                    questionIndex++;
                    showQuestions();
                }
            }
            else {
                SceneManager.LoadScene("QuizFinished");
            }
        }
        else { 
            //toggle incorrect popup
            panelIncorrect.gameObject.SetActive(true);
            if (this.isBonusQuestion)
            {
                correctAnswer.text = "That is Incorrect!\nThe Correct answer is " + bonusAnswers[bonusIndex];
            }
            else
            {
                correctAnswer.text = "That is Incorrect!\nThe Correct answer is " + answers[questionIndex];
            }
            if (questionIndex < questions.Length - 1)
            {
                questionIndex++;
                showQuestions();
            }
            else
            {
                SceneManager.LoadScene("QuizFinished");
            }
        }
    }

    public void CorrectClick() {
        panelCorrect.gameObject.SetActive(false);
    }

    public void IncorrectClick()
    {
        panelIncorrect.gameObject.SetActive(false);

    }

    public List<int> getAnswerOptionList(int answer) {
        List<int> temp = new List<int>();
        List <int> listNumber = new List<int>();
        //generate difference (random number between 0 & 3
        int difference = rng.Next(0, 3);
        //generate two random numbers between answer - difference and answer + difference
        
        
        
        int one = Math.Abs(rng.Next(answer-difference, answer+difference));
        int two = Math.Abs(rng.Next(answer - difference, answer + difference));
        Boolean isGood = false;
        while (!isGood)
        {
            if (one == answer)
            {
                one = (one + rng.Next(1, 3));
            }
            else if (two == answer)
            {
                two = (two + rng.Next(1, 3));
            }
            else if (one == two)
            {
                one = (one + rng.Next(1, 3));
            }
            else {
                isGood = true;
            }
        }
        temp.Add(answer);
        temp.Add(Math.Abs(one));
        temp.Add(Math.Abs(two));
        return temp;
    }
    public void checkPoints()
    {
        //set all engines to inactive
        engine.gameObject.SetActive(false);
        engineOne.gameObject.SetActive(false);
        engineTwo.gameObject.SetActive(false);
        engineThree.gameObject.SetActive(false);
        engineFour.gameObject.SetActive(false);
        engineFive.gameObject.SetActive(false);
        engineSix.gameObject.SetActive(false);
        engineSeven.gameObject.SetActive(false);
        engineEight.gameObject.SetActive(false);
        engineNine.gameObject.SetActive(false);
        caboose.gameObject.SetActive(false);
        int points = Convert.ToInt32(totalScore);
        if (points < 30)
        {
            engine.gameObject.SetActive(true);
        }
        else if (points >= 30 && points < 70)
        {
            engineOne.gameObject.SetActive(true);
        }
        else if (points >= 70 && points < 100)
        {
            engineTwo.gameObject.SetActive(true);
        }
        else if (points >= 100 && points < 300)
        {
            engineThree.gameObject.SetActive(true);
        }
        else if (points >= 300 && points < 700)
        {
            engineFour.gameObject.SetActive(true);
        }
        else if (points >= 700 && points < 1000)
        {
            engineSix.gameObject.SetActive(true);
        }
        else if (points >= 1000 && points < 30000)
        {
            engineSeven.gameObject.SetActive(true);
        }
        else if (points >= 30000 && points < 70000)
        {
            engineEight.gameObject.SetActive(true);
        }
        else if (points >= 70000 && points < 11100)
        {
            engineNine.gameObject.SetActive(true);
        }
        else
        {
            caboose.gameObject.SetActive(true);
        }
    }

    public void levelComplete ()
    {
        panelLevelComplete.gameObject.SetActive(false);

        if (questionIndex == 7)
        {
            panelLevelComplete.gameObject.SetActive(true);
        }
    }

    public Boolean checkCorrectQuestionCount() {
        if (correctQuestionsCount == 3)
        {
            return true;
        }
        else {
            return false;
        }
    }

    private void showBonusQuestions()
    {
        //make sure popups are inactive
        question.text = bonusQuestions[bonusIndex];
        btn1.text = "" + bonusOptions[bonusIndex][0];
        btn2.text = "" + bonusOptions[bonusIndex][1]; 
        btn3.text = "" + bonusOptions[bonusIndex][2];
    }

}
