﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;
public class TeacherProgressPageController : MonoBehaviour
{
    public Text name;
    public Text totalScore;
    public Text level;
    public GameObject engine;
    public GameObject engineOne;
    public GameObject engineTwo;
    public GameObject engineThree;
    public GameObject engineFour;
    public GameObject engineFive;
    public GameObject engineSix;
    public GameObject engineSeven;
    public GameObject engineEight;
    public GameObject engineNine;
    public GameObject caboose;
    DatabaseController databaseController = new DatabaseController();
    // Start is called before the first frame update
    void Start()
    {
        string studentName = PlayerPrefs.GetString("CurrentStudent");
        name.text = studentName;
        totalScore.text = "" + databaseController.getTotalScore(studentName);
        level.text = "" + databaseController.getLevel(studentName);
        this.checkPoints();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void backButton() {
        SceneManager.LoadScene("TeacherScreen");
    }

    public void checkPoints()
    {
        //set all engines to inactive
        engine.gameObject.SetActive(false);
        engineOne.gameObject.SetActive(false);
        engineTwo.gameObject.SetActive(false);
        engineThree.gameObject.SetActive(false);
        engineFour.gameObject.SetActive(false);
        engineFive.gameObject.SetActive(false);
        engineSix.gameObject.SetActive(false);
        engineSeven.gameObject.SetActive(false);
        engineEight.gameObject.SetActive(false);
        engineNine.gameObject.SetActive(false);
        caboose.gameObject.SetActive(false);
        int points = Convert.ToInt32(totalScore);
        if (points < 30)
        {
            engine.gameObject.SetActive(true);
        }
        else if (points >= 30 && points < 70)
        {
            engineOne.gameObject.SetActive(true);
        }
        else if (points >= 70 && points < 100)
        {
            engineTwo.gameObject.SetActive(true);
        }
        else if (points >= 100 && points < 300)
        {
            engineThree.gameObject.SetActive(true);
        }
        else if (points >= 300 && points < 700)
        {
            engineFour.gameObject.SetActive(true);
        }
        else if (points >= 700 && points < 1000)
        {
            engineSix.gameObject.SetActive(true);
        }
        else if (points >= 1000 && points < 30000)
        {
            engineSeven.gameObject.SetActive(true);
        }
        else if (points >= 30000 && points < 70000)
        {
            engineEight.gameObject.SetActive(true);
        }
        else if (points >= 70000 && points < 11100)
        {
            engineNine.gameObject.SetActive(true);
        }
        else
        {
            caboose.gameObject.SetActive(true);
        }
    }
}
